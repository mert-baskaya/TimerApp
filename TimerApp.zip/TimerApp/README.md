TimerApp

A basic timer app that uses bottom tab navigation.
